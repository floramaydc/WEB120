<aside>
    <div class="subnav">
        <h2>Quick Links</h2>
        <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="brands.php">Brands</a></li>
        </ul>
    </div>
    <div class="subnav">
        <h2>Important Information</h2>
      <ul>
        <li><a href="#nowhere" title="Lorum ipsum dolor sit amet">Lorem</a></li>
        <li><a href="#nowhere" title="Aliquam tincidunt mauris eu risus">Aliquam</a></li>
        <li><a href="#nowhere" title="Morbi in sem quis dui placerat ornare">Morbi</a></li>
        <li><a href="#nowhere" title="Praesent dapibus, neque id cursus faucibus">Praesent</a></li>
        <li><a href="#nowhere" title="Pellentesque fermentum dolor">Pellentesque</a></li>
      </ul>
    </div>
</aside>