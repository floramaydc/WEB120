<div id="pages" class="page1">
        <!--Begin Action-->
        <!--<img src="images/default-header.jpg"/>-->
        <h2>Put your brand on the map</h2>
        <a href="#">Expand Now</a>
        <!--End Action-->
        </div>
        <div id="pages" class="page2">
        <!--Begin Subpages of Page 2-->
            <div class="floating-box">
                <i class="fa fa-handshake-o" aria-hidden="true" style="font-size:100px;color:forestgreen; padding:3px;"></i>
                <p><a href="#">The Team</a></p>
                <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
            </div>
            <div class="floating-box">
                <i class="fa fa-money" aria-hidden="true" style="font-size:100px;color:forestgreen; padding:3px;"></i>
                <p><a href="#">The Stakeholders</a></p>
                <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
            </div>
            <div class="floating-box">
                <i class="fa fa-recycle" aria-hidden="true" style="font-size:100px;color:forestgreen; padding:3px;"></i>
                <p><a href="#">The Processes</a></p>
                <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
            </div>
            <div class="floating-box">
                <i class="fa fa-question" aria-hidden="true" style="font-size:100px;color:forestgreen; padding:3px;"></i>
                <p><a href="#">FAQ</a></p>
                <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
            </div>
        <!--End Subpages of Page 2-->
        </div>
        <div id="pages" class="page3">
        <!--Begin Flexslider-->
            <b>Featured Brand.</b> Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.
        <!--End Flexslider-->
        </div>
        <div id="pages" class="page4">
        <!--Begin Links-->
        <!--End Links-->
        </div>


----

    vertical-align: text-top;
    left: 0px;
    top: 0px;
    z-index: -1;
----

