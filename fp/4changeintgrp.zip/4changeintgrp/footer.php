<div class="containers" id="footer">
    <footer>
        <p><a href="index.php">Home</a>
            <a href="aboutus.php">About Us</a>
            <a href="services.php">Services</a>
            <a href="brands.php">Brands</a>
            <a href="contactus.php">Contact Us</a></p>
        <p><small>2016 - 2017 by <a href="#" target="_blank">4Change International Group</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer></div>
</div><!--close main-container div-->
</div><!--closing wrappers div-->
</body>
</html>