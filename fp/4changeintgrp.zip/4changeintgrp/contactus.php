<?php include 'inc/config.php'; ?>
<?php include 'header.php'; ?>
<div class="main-container">
    <div class="containers container1" id="container1"><!--Page 1-->
        <!--Begin Action-->
        <!--<img src="images/default-header.jpg"/>-->
        <h2><?=$aboutpage?></h2>
        <!--End Action-->
    </div>
    <div class="containers" id="container2"><!--Page 2-->
    <section>
        <?php include 'inc/simple.php'; ?>
    </section>
    <?php include 'sidebar.php'; ?>
    </div>
<?php include 'footer.php'; ?>