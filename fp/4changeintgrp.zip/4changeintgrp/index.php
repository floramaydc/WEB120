<?php include 'inc/config.php'; ?>
<?php include 'header.php'; ?>
<?php include 'main.php'; ?>
<?php include 'footer.php'; ?>